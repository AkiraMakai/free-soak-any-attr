/**
 * Free Soak Any Attribute (SWADE House Rule)
 * Foundry VTT v12 + SWADE 4.4.4 + Better Rolls 2 friendly
 *
 * Changes:
 * - Soak costs 0 Bennies
 * - Choose ANY Attribute for Soak
 * - Works with Better Rolls 2 "Soak (Vigor) roll" button
 * - Correctly calculates wounds remaining from the damage instance
 * - Applies wounds correctly whether the damage was already applied OR not yet applied
 *
 * Escape hatch:
 * - Shift+Click the Soak button to let original behavior run.
 */

const MODULE_ID = "free-soak-any-attr";

Hooks.once("init", () => {
  console.log(`[${MODULE_ID}] Init (FVTT v12 / SWADE 4.4.4 / Better Rolls 2 compatible)`);
});

Hooks.on("renderChatMessage", (message, html) => {
  if (game.system?.id !== "swade") return;

  // Better Rolls 2 sometimes uses <a> elements styled as buttons
  const clickable = html.find("button, a");

  for (const el of clickable) {
    const node = el instanceof HTMLElement ? el : el?.[0];
    if (!node) continue;

    const label = (node.textContent || "").trim();
    const lowerLabel = label.toLowerCase();

    const ds = node.dataset ?? {};
    const action = String(ds.action || ds.operation || ds.cardAction || ds.brAction || "").toLowerCase();

    // Detect "Soak" including Better Rolls 2 string: "Soak (Vigor) roll"
    const looksLikeSoak =
      action.includes("soak") ||
      lowerLabel === "soak" ||
      lowerLabel.includes("soak") ||
      lowerLabel.includes("soak (");

    if (!looksLikeSoak) continue;

    // Cosmetic tweak: rename Better Rolls button label
    // Only change labels that look like "Soak (Vigor) roll"
    if (lowerLabel.includes("soak (") && lowerLabel.includes(")")) {
      // If this element is not a plain text node, keep it simple: replace textContent.
      node.textContent = "Soak roll";
    }

    // Prevent double-binding when chat re-renders
    if (ds.freeSoakBound === "1") continue;
    ds.freeSoakBound = "1";

    node.addEventListener(
      "click",
      async (ev) => {
        // Escape hatch: Shift+Click uses original behavior
        if (ev.shiftKey) return;

        // Critical for Better Rolls 2: stop its handler from firing
        ev.preventDefault();
        ev.stopPropagation();
        ev.stopImmediatePropagation();

        try {
          await handleFreeSoak({ message, button: node });
        } catch (err) {
          console.error(`[${MODULE_ID}] Soak failed:`, err);
          ui.notifications?.error("Free Soak Any Attribute: failed. Check console (F12).");
        }
      },
      true // capture phase: intercept before Better Rolls handlers
    );
  }
});

async function handleFreeSoak({ message, button }) {
  const actor = await resolveActorFromContext({ message, button });
  if (!actor) {
    ui.notifications?.warn("Free Soak: Could not find the damaged actor for this Soak.");
    console.warn(`[${MODULE_ID}] Could not resolve actor`, { message, dataset: button?.dataset });
    return;
  }

  // Wounds this damage instance would inflict (best-effort).
  const pendingWounds = resolvePendingWounds({ message, button });

  const chosenAttr = await promptForAttribute(actor);
  if (!chosenAttr) return;

  const roll = await rollAttribute(actor, chosenAttr);
  const total = Number(roll?.total ?? roll?.result ?? NaN);
  const soaked = computeSoakFromTotal(total);

  // Wounds remaining for THIS damage instance.
  // If pendingWounds isn't found, we still behave sensibly: remaining = unknown.
  const woundsRemainingInstance = Number.isFinite(pendingWounds)
    ? Math.max(pendingWounds - soaked, 0)
    : null;

  // Apply to actor in a way that works whether damage was already applied or not.
  const currentWounds = Number(
    getProp(actor, "system.wounds.value") ??
      getProp(actor, "system.wounds") ?? // some setups store as number
      getProp(actor, "data.data.wounds.value") ??
      getProp(actor, "data.data.wounds") ??
      0
  );

  let newActorWounds = currentWounds;

  if (Number.isFinite(pendingWounds)) {
    // If the actor already has at least the pending wounds reflected in its current wounds,
    // we assume damage already applied, so we reduce.
    //
    // Otherwise, we assume the damage hasn't been applied yet, so we apply only the remaining wounds.
    if (currentWounds >= pendingWounds) {
      // Applied already -> subtract soaked (capped by pending)
      newActorWounds = Math.max(currentWounds - Math.min(soaked, pendingWounds), 0);
    } else {
      // Not applied yet -> add remaining wounds
      newActorWounds = Math.max(currentWounds + Math.max(pendingWounds - soaked, 0), 0);
    }

    // Update actor wounds (system path first, legacy fallback)
    await updateActorWounds(actor, newActorWounds);
  } else {
    // If we can't determine pending wounds from the card, we won't touch actor wounds automatically.
    // Still report the soak roll result in chat.
    console.warn(`[${MODULE_ID}] Could not determine pending wounds from chat card; not applying wound changes automatically.`);
  }

  const attrLabel = attributeLabel(chosenAttr);

  const pendingText = Number.isFinite(pendingWounds)
    ? `<p>Wounds from hit: <b>${pendingWounds}</b> | Soaked: <b>${soaked}</b> | Wounds remaining: <b>${woundsRemainingInstance}</b></p>`
    : `<p>Soaked: <b>${soaked}</b> (could not read wounds-from-hit from this card)</p>`;

  await ChatMessage.create({
    user: game.user.id,
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `
      <div class="swade">
        <h3>Soak (House Rule)</h3>
        <p><b>${escapeHtml(actor.name)}</b> rolls <b>${escapeHtml(attrLabel)}</b>: <b>${Number.isFinite(total) ? total : "?"}</b></p>
        ${pendingText}
        ${
          Number.isFinite(pendingWounds)
            ? `<p style="opacity:0.85">Actor wounds now: <b>${newActorWounds}</b></p>`
            : ""
        }
        <p style="opacity:0.8">Bennies spent: <b>0</b></p>
      </div>
    `
  });
}

async function updateActorWounds(actor, newWounds) {
  // SWADE typically uses system.wounds.value, but be tolerant.
  try {
    const woundsObj = getProp(actor, "system.wounds");
    if (woundsObj && typeof woundsObj === "object" && "value" in woundsObj) {
      await actor.update({ "system.wounds.value": newWounds });
      return;
    }
    // Some variants store wounds as a number
    if (typeof woundsObj === "number") {
      await actor.update({ "system.wounds": newWounds });
      return;
    }

    // Legacy fallback
    const legacyWoundsObj = getProp(actor, "data.data.wounds");
    if (legacyWoundsObj && typeof legacyWoundsObj === "object" && "value" in legacyWoundsObj) {
      await actor.update({ "data.wounds.value": newWounds });
      return;
    }
    if (typeof legacyWoundsObj === "number") {
      await actor.update({ "data.wounds": newWounds });
      return;
    }

    // Last resort
    await actor.update({ "system.wounds.value": newWounds });
  } catch (e) {
    console.error(`[${MODULE_ID}] Failed to update actor wounds`, e);
    throw e;
  }
}

async function resolveActorFromContext({ message, button }) {
  // 1) Speaker actor
  const speakerActorId = message?.speaker?.actor;
  if (speakerActorId) {
    const a = game.actors?.get(speakerActo
