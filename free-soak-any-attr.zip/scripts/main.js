const MODULE_ID = "free-soak-any-attr";

Hooks.once("init", () => {
  console.log(`[${MODULE_ID}] Initializing (FVTT v12 / SWADE 4.4.4 support mode)`);
});

Hooks.on("renderChatMessage", (message, html) => {
  if (game.system?.id !== "swade") return;

  // Find a "Soak" button inside this chat message.
  const buttons = html.find("button");

  for (const btnEl of buttons) {
    const btn = btnEl instanceof HTMLElement ? btnEl : btnEl[0];
    if (!btn) continue;

    const label = (btn.textContent || "").trim().toLowerCase();
    const action = (btn.dataset.action || btn.dataset.operation || btn.dataset.cardAction || "").toLowerCase();

    const looksLikeSoak =
      action.includes("soak") ||
      label === "soak" ||
      label.includes("soak");

    if (!looksLikeSoak) continue;

    // Prevent double-binding on re-render
    if (btn.dataset.freeSoakBound === "1") continue;
    btn.dataset.freeSoakBound = "1";

    btn.addEventListener(
      "click",
      async (ev) => {
        // Escape hatch: Shift+Click uses original behavior
        if (ev.shiftKey) return;

        ev.preventDefault();
        ev.stopPropagation();

        try {
          await handleFreeSoak({ message, button: btn });
        } catch (err) {
          console.error(`[${MODULE_ID}] Soak failed:`, err);
          ui.notifications?.error("Free Soak module failed. Check console (F12).");
        }
      },
      true
    );
  }
});

async function handleFreeSoak({ message, button }) {
  const actor = await resolveActorFromContext({ message, button });
  if (!actor) {
    ui.notifications?.warn("Free Soak: Could not find the damaged actor for this Soak.");
    console.warn(`[${MODULE_ID}] Could not resolve actor`, { message, dataset: button?.dataset });
    return;
  }

  const pendingWounds = resolvePendingWounds({ message, button });

  const chosenAttr = await promptForAttribute(actor);
  if (!chosenAttr) return;

  const roll = await rollAttribute(actor, chosenAttr);

  const total = Number(roll?.total ?? roll?.result ?? NaN);
  const soaked = computeSoakFromTotal(total);

  // Damage was already applied, so we reduce CURRENT wounds.
  const currentWounds = Number(getProp(actor, "system.wounds.value") ?? getProp(actor, "data.data.wounds.value") ?? 0);

  // If we know how many wounds this damage application inflicted, cap by it; otherwise cap by soaked.
  const cap = Number.isFinite(pendingWounds) ? pendingWounds : soaked;

  const reduceBy = Math.min(soaked, Math.max(cap, 0), currentWounds);
  const newWounds = Math.max(currentWounds - reduceBy, 0);

  // Update using system path first; fallback to legacy path if needed.
  try {
    await actor.update({ "system.wounds.value": newWounds });
  } catch (e) {
    await actor.update({ "data.wounds.value": newWounds });
  }

  const attrLabel = attributeLabel(chosenAttr);
  const pendingText = Number.isFinite(pendingWounds) ? ` (pending: ${pendingWounds})` : "";

  await ChatMessage.create({
    user: game.user.id,
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `
      <div class="swade">
        <h3>Soak (House Rule)</h3>
        <p><b>${actor.name}</b> rolls <b>${attrLabel}</b>${pendingText}: <b>${Number.isFinite(total) ? total : "?"}</b></p>
        <p>Soaked: <b>${soaked}</b> | Wounds reduced: <b>${reduceBy}</b> | New wounds: <b>${newWounds}</b></p>
        <p style="opacity:0.8">Bennies spent: <b>0</b></p>
      </div>
    `
  });
}

async function resolveActorFromContext({ message, button }) {
  // 1) Speaker actor
  const speakerActorId = message?.speaker?.actor;
  if (speakerActorId) {
    const a = game.actors?.get(speakerActorId);
    if (a) return a;
  }

  // 2) Dataset UUID / actorId
  const ds = button?.dataset ?? {};
  const uuid = ds.actorUuid || ds.uuid || ds.documentUuid;
  if (uuid) {
    const doc = await fromUuid(uuid);
    if (doc?.documentName === "Actor") return doc;
    if (doc?.actor) return doc.actor;
  }

  const actorId = ds.actorId || ds.actor;
  if (actorId) {
    const a = game.actors?.get(actorId);
    if (a) return a;
  }

  // 3) Flags (different swade versions store different keys)
  const flagUuid =
    getProp(message, "flags.swade.actorUuid") ||
    getProp(message, "flags.swade.actor") ||
    getProp(message, "flags.swade.data.actorUuid") ||
    getProp(message, "flags.swade.damage.actorUuid");

  if (flagUuid) {
    const doc = await fromUuid(flagUuid);
    if (doc?.documentName === "Actor") return doc;
    if (doc?.actor) return doc.actor;
  }

  // 4) Token fallback (if dataset references token)
  const tokenUuid = ds.tokenUuid || ds.token;
  if (tokenUuid) {
    const tdoc = await fromUuid(tokenUuid);
    if (tdoc?.actor) return tdoc.actor;
  }

  return null;
}

function resolvePendingWounds({ message, button }) {
  // Best-effort: depends on which damage automation produced the chat card.
  const ds = button?.dataset ?? {};
  const direct =
    ds.wounds ??
    ds.pendingWounds ??
    ds.appliedWounds ??
    ds.wound ??
    ds.w;

  const fromDataset = toNumberOrNaN(direct);
  if (Number.isFinite(fromDataset)) return fromDataset;

  // Try likely flag locations
  const fromFlags =
    toNumberOrNaN(getProp(message, "flags.swade.damage.wounds")) ||
    toNumberOrNaN(getProp(message, "flags.swade.damageData.wounds")) ||
    toNumberOrNaN(getProp(message, "flags.swade.wounds")) ||
    toNumberOrNaN(getProp(message, "flags.swade.damageContext.wounds")) ||
    NaN;

  if (Number.isFinite(fromFlags)) return fromFlags;

  // Parse from tooltip if present
  const title = (button?.title || "").toLowerCase();
  const m = title.match(/(\d+)\s*wound/);
  if (m) return Number(m[1]);

  return NaN;
}

function getProp(obj, path) {
  // FVTT v12 has foundry.utils.getProperty; this wrapper also prevents hard crashes.
  try {
    return foundry?.utils?.getProperty ? foundry.utils.getProperty(obj, path) : path.split(".").reduce((o, k) => o?.[k], obj);
  } catch {
    return undefined;
  }
}

function toNumberOrNaN(v) {
  if (v === undefined || v === null || v === "") return NaN;
  const n = Number(v);
  return Number.isFinite(n) ? n : NaN;
}

async function promptForAttribute(actor) {
  const attrs = ["agility", "smarts", "spirit", "strength", "vigor"];
  const options = attrs.map(a => `<option value="${a}">${attributeLabel(a)}</option>`).join("");

  const content = `
    <form>
      <div class="form-group">
        <label>Choose Attribute for Soak</label>
        <select name="attr">${options}</select>
        <p class="notes">House rule: Soak costs 0 Bennies and may use any Attribute.</p>
      </div>
    </form>
  `;

  return await new Promise((resolve) => {
    new Dialog({
      title: `Soak (House Rule): ${actor.name}`,
      content,
      buttons: {
        ok: {
          label: "Roll Soak",
          callback: (html) => resolve(String(html.find("select[name='attr']").val()))
        },
        cancel: {
          label: "Cancel",
          callback: () => resolve(null)
        }
      },
      default: "ok"
    }).render(true);
  });
}

function attributeLabel(key) {
  return {
    agility: "Agility",
    smarts: "Smarts",
    spirit: "Spirit",
    strength: "Strength",
    vigor: "Vigor"
  }[key] ?? key;
}

async function rollAttribute(actor, attrKey) {
  // Try SWADE methods (vary by version)
  if (typeof actor.rollAttribute === "function") {
    return await actor.rollAttribute(attrKey);
  }

  // Some versions expose rollTrait with a data path
  if (typeof actor.rollTrait === "function") {
    // Common SWADE trait path is system.attributes.<attr>
    // but some methods expect the "key" only; we try both.
    try {
      return await actor.rollTrait(`system.attributes.${attrKey}`);
    } catch (e) {
      try {
        return await actor.rollTrait(attrKey);
      } catch {
        // fall through
      }
    }
  }

  // Fallback: trait die + wild die, ace, take highest.
  const traitSides =
    getProp(actor, `system.attributes.${attrKey}.die.sides`) ??
    getProp(actor, `data.data.attributes.${attrKey}.die.sides`);

  const wildSides =
    getProp(actor, `system.wildDie.sides`) ??
    getProp(actor, `data.data.wildDie.sides`) ??
    6;

  if (!traitSides) throw new Error(`Missing attribute die data for: ${attrKey}`);

  const traitRoll = await new Roll(`1d${traitSides}x`).evaluate({ async: true });
  const wildRoll = await new Roll(`1d${wildSides}x`).evaluate({ async: true });

  // Show both rolls to chat so it feels like SWADE
  await traitRoll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `Soak (House Rule) - ${attributeLabel(attrKey)} (Trait Die)`
  });

  await wildRoll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `Soak (House Rule) - Wild Die`
  });

  return { total: Math.max(traitRoll.total, wildRoll.total) };
}

function computeSoakFromTotal(total) {
  if (!Number.isFinite(total) || total < 4) return 0;
  const raises = Math.floor((total - 4) / 4);
  return 1 + raises;
}
