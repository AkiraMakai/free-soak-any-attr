/**
 * Free Soak Any Attribute (SWADE House Rule)
 * FVTT v12 + SWADE 4.4.4 + Better Rolls 2: GLOBAL CAPTURE INTERCEPT
 *
 * This uses a single document-level capture listener so other modules
 * cannot easily “outrun” our click intercept.
 *
 * Shift+Click = allow default behavior.
 */

const MODULE_ID = "free-soak-any-attr";

Hooks.once("init", () => {
  console.warn(`[${MODULE_ID}] Loaded (global click interceptor active)`);

  // Only register once
  if (window.__freeSoakGlobalListenerInstalled) return;
  window.__freeSoakGlobalListenerInstalled = true;

  document.addEventListener(
    "click",
    async (ev) => {
      try {
        await onGlobalClick(ev);
      } catch (err) {
        console.error(`[${MODULE_ID}] Global click handler error:`, err);
      }
    },
    true // capture phase
  );
});

async function onGlobalClick(ev) {
  if (game.system?.id !== "swade") return;
  if (ev.shiftKey) return;

  const target = ev.target;
  if (!(target instanceof HTMLElement)) return;

  // Only care about clicks inside the chat log
  const chatMessageEl = target.closest("li.chat-message[data-message-id]");
  if (!chatMessageEl) return;

  const messageId = chatMessageEl.dataset.messageId;
  if (!messageId) return;

  const message = game.messages?.get(messageId);
  if (!message) return;

  // Find the clicked control (button/link/etc.)
  const control = target.closest("button, a, input[type='button'], [role='button']");
  if (!(control instanceof HTMLElement)) return;

  // Identify as Soak control
  const label = (control.textContent || control.getAttribute("aria-label") || "").trim().toLowerCase();
  const ds = control.dataset ?? {};
  const action = String(ds.action || ds.operation || ds.cardAction || ds.brAction || "").toLowerCase();

  const looksLikeSoak =
    action.includes("soak") ||
    label === "soak" ||
    label.includes("soak") ||
    label.includes("soak ("); // Better Rolls: "Soak (Vigor) roll"

  if (!looksLikeSoak) return;

  // If we got here, we are definitely intercepting the soak click.
  // Cancel everything else (including Better Rolls).
  ev.preventDefault();
  ev.stopPropagation();
  ev.stopImmediatePropagation();

  console.warn(`[${MODULE_ID}] Intercepted Soak click on message ${messageId}`);

  await handleFreeSoak({ message, control });
}

async function handleFreeSoak({ message, control }) {
  const actor = await resolveActorFromContext({ message, control });
  if (!actor) {
    ui.notifications?.warn("Free Soak: Could not determine the damaged actor.");
    console.warn(`[${MODULE_ID}] Actor resolution failed`, { message, dataset: control?.dataset });
    return;
  }

  const pendingWounds = resolvePendingWounds({ message, control });

  const chosenAttr = await promptForAttribute(actor);
  if (!chosenAttr) return;

  const roll = await rollAttribute(actor, chosenAttr);
  const total = Number(roll?.total ?? roll?.result ?? NaN);
  const soaked = computeSoakFromTotal(total);

  const woundsKnown = Number.isFinite(pendingWounds);
  const woundsRemaining = woundsKnown ? Math.max(pendingWounds - soaked, 0) : null;

  await ChatMessage.create({
    user: game.user.id,
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `
      <div class="swade">
        <h3>Soak (House Rule)</h3>
        <p><b>${escapeHtml(actor.name)}</b> rolls <b>${escapeHtml(attributeLabel(chosenAttr))}</b>: <b>${Number.isFinite(total) ? total : "?"}</b></p>
        ${
          woundsKnown
            ? `<p>Wounds from hit: <b>${pendingWounds}</b> | Soaked: <b>${soaked}</b> | Wounds remaining: <b>${woundsRemaining}</b></p>`
            : `<p>Soaked: <b>${soaked}</b> (could not read wounds-from-hit from this card)</p>`
        }
        <p style="opacity:0.8">Bennies spent: <b>0</b></p>
      </div>
    `
  });
}

async function resolveActorFromContext({ message, control }) {
  // 1) Speaker actor
  const speakerActorId = message?.speaker?.actor;
  if (speakerActorId) {
    const a = game.actors?.get(speakerActorId);
    if (a) return a;
  }

  const ds = control?.dataset ?? {};

  // 2) Dataset uuid / actor id
  const uuid = ds.actorUuid || ds.uuid || ds.documentUuid;
  if (uuid) {
    const doc = await fromUuid(uuid);
    if (doc?.documentName === "Actor") return doc;
    if (doc?.actor) return doc.actor;
  }

  const actorId = ds.actorId || ds.actor;
  if (actorId) {
    const a = game.actors?.get(actorId);
    if (a) return a;
  }

  // 3) Better Rolls flags (common)
  const brUuid =
    getProp(message, "flags.betterRolls.actorUuid") ||
    getProp(message, "flags.betterRolls.tokenUuid") ||
    getProp(message, "flags.betterrolls.actorUuid") ||
    getProp(message, "flags.betterrolls.tokenUuid");

  if (brUuid) {
    const doc = await fromUuid(brUuid);
    if (doc?.actor) return doc.actor;
    if (doc?.documentName === "Actor") return doc;
  }

  // 4) SWADE flags
  const swadeUuid =
    getProp(message, "flags.swade.actorUuid") ||
    getProp(message, "flags.swade.actor") ||
    getProp(message, "flags.swade.data.actorUuid") ||
    getProp(message, "flags.swade.damage.actorUuid");

  if (swadeUuid) {
    const doc = await fromUuid(swadeUuid);
    if (doc?.documentName === "Actor") return doc;
    if (doc?.actor) return doc.actor;
  }

  // 5) token fallback
  const tokenUuid = ds.tokenUuid || ds.token;
  if (tokenUuid) {
    const tdoc = await fromUuid(tokenUuid);
    if (tdoc?.actor) return tdoc.actor;
  }

  return null;
}

function resolvePendingWounds({ message, control }) {
  const ds = control?.dataset ?? {};

  const direct = ds.wounds ?? ds.pendingWounds ?? ds.appliedWounds ?? ds.wound ?? ds.w;
  const fromDataset = toNumberOrNaN(direct);
  if (Number.isFinite(fromDataset)) return fromDataset;

  const fromFlags =
    toNumberOrNaN(getProp(message, "flags.swade.damage.wounds")) ||
    toNumberOrNaN(getProp(message, "flags.swade.damageData.wounds")) ||
    toNumberOrNaN(getProp(message, "flags.swade.wounds")) ||
    NaN;
  if (Number.isFinite(fromFlags)) return fromFlags;

  // Better Rolls text: "has been damaged for X wound(s)"
  const plain = stripHtml(message?.content ?? "");
  const m = plain.match(/damaged for\s+(\d+)\s*wound/i);
  if (m) return Number(m[1]);

  return NaN;
}

async function promptForAttribute(actor) {
  const attrs = ["agility", "smarts", "spirit", "strength", "vigor"];
  const options = attrs.map(a => `<option value="${a}">${escapeHtml(attributeLabel(a))}</option>`).join("");

  return await new Promise((resolve) => {
    new Dialog({
      title: `Soak (House Rule): ${actor.name}`,
      content: `
        <form>
          <div class="form-group">
            <label>Choose Attribute for Soak</label>
            <select name="attr">${options}</select>
            <p class="notes">House rule: Soak costs 0 Bennies and may use any Attribute.</p>
          </div>
        </form>
      `,
      buttons: {
        ok: { label: "Roll Soak", callback: (html) => resolve(String(html.find("select[name='attr']").val())) },
        cancel: { label: "Cancel", callback: () => resolve(null) }
      },
      default: "ok"
    }).render(true);
  });
}

async function rollAttribute(actor, attrKey) {
  if (typeof actor.rollAttribute === "function") return await actor.rollAttribute(attrKey);

  if (typeof actor.rollTrait === "function") {
    try { return await actor.rollTrait(`system.attributes.${attrKey}`); }
    catch { try { return await actor.rollTrait(attrKey); } catch {} }
  }

  const traitSides =
    getProp(actor, `system.attributes.${attrKey}.die.sides`) ??
    getProp(actor, `data.data.attributes.${attrKey}.die.sides`);

  const wildSides =
    getProp(actor, `system.wildDie.sides`) ??
    getProp(actor, `data.data.wildDie.sides`) ??
    6;

  if (!traitSides) throw new Error(`Missing attribute die data for: ${attrKey}`);

  const traitRoll = await new Roll(`1d${traitSides}x`).evaluate({ async: true });
  const wildRoll = await new Roll(`1d${wildSides}x`).evaluate({ async: true });

  await traitRoll.toMessage({ speaker: ChatMessage.getSpeaker({ actor }), flavor: `Soak (House Rule) - ${attributeLabel(attrKey)} (Trait)` });
  await wildRoll.toMessage({ speaker: ChatMessage.getSpeaker({ actor }), flavor: `Soak (House Rule) - Wild Die` });

  return { total: Math.max(traitRoll.total, wildRoll.total) };
}

function computeSoakFromTotal(total) {
  if (!Number.isFinite(total) || total < 4) return 0;
  return 1 + Math.floor((total - 4) / 4);
}

function attributeLabel(key) {
  return ({ agility:"Agility", smarts:"Smarts", spirit:"Spirit", strength:"Strength", vigor:"Vigor" }[key] ?? key);
}

function toNumberOrNaN(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : NaN;
}

function getProp(obj, path) {
  try {
    if (foundry?.utils?.getProperty) return foundry.utils.getProperty(obj, path);
    return path.split(".").reduce((o, k) => o?.[k], obj);
  } catch { return undefined; }
}

function stripHtml(html) {
  const div = document.createElement("div");
  div.innerHTML = String(html ?? "");
  return (div.textContent || "").trim();
}

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
