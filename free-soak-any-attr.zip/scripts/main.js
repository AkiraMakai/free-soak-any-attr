/**
 * Free Soak Any Attribute (SWADE House Rule)
 * Foundry VTT v12 + SWADE 4.4.4 + Better Rolls 2 compatible
 *
 * - Intercepts any Soak button/link on damage cards (including Better Rolls "Soak (Vigor) roll")
 * - Prevents default behavior (no Benny spend, no forced Vigor)
 * - Prompts for Attribute
 * - Rolls chosen Attribute
 * - Computes wounds remaining for the hit (from the message text) and updates actor wounds if possible
 *
 * Escape hatch: Shift+Click = original behavior
 */

const MODULE_ID = "free-soak-any-attr";

Hooks.once("init", () => {
  console.log(`[${MODULE_ID}] Init`);
});

Hooks.on("renderChatMessage", (message, html) => {
  if (game.system?.id !== "swade") return;

  // Avoid rebinding on re-render
  const root = html?.[0];
  if (!root) return;
  if (root.dataset.freeSoakDelegated === "1") return;
  root.dataset.freeSoakDelegated = "1";

  // Capture-phase delegated click handler (beats Better Rolls handlers)
  root.addEventListener(
    "click",
    async (ev) => {
      // Escape hatch
      if (ev.shiftKey) return;

      const target = ev.target;
      if (!(target instanceof HTMLElement)) return;

      // Find the nearest clickable control
      const control = target.closest("button, a, input[type='button'], [role='button']");
      if (!(control instanceof HTMLElement)) return;

      // Determine if this control is a Soak control
      const label = (control.textContent || control.getAttribute("aria-label") || "").trim().toLowerCase();
      const ds = control.dataset ?? {};
      const action = String(ds.action || ds.operation || ds.cardAction || ds.brAction || "").toLowerCase();

      const looksLikeSoak =
        action.includes("soak") ||
        label === "soak" ||
        label.includes("soak") ||
        label.includes("soak ("); // Better Rolls: "Soak (Vigor) roll"

      if (!looksLikeSoak) return;

      // If we got here, it's ours. Cancel everything else.
      ev.preventDefault();
      ev.stopPropagation();
      ev.stopImmediatePropagation();

      try {
        await handleFreeSoak({ message, control });
      } catch (err) {
        console.error(`[${MODULE_ID}] Soak failed:`, err);
        ui.notifications?.error("Free Soak Any Attribute failed. Check console (F12).");
      }
    },
    true
  );
});

async function handleFreeSoak({ message, control }) {
  const actor = await resolveActorFromContext({ message, control });
  if (!actor) {
    ui.notifications?.warn("Free Soak: Could not determine the damaged actor.");
    console.warn(`[${MODULE_ID}] Actor resolution failed`, { message, dataset: control?.dataset });
    return;
  }

  // Better Rolls text usually includes: "has been damaged for X wound(s)"
  const pendingWounds = resolvePendingWounds({ message, control });

  const chosenAttr = await promptForAttribute(actor);
  if (!chosenAttr) return;

  const roll = await rollAttribute(actor, chosenAttr);
  const total = Number(roll?.total ?? roll?.result ?? NaN);
  const soaked = computeSoakFromTotal(total);

  const woundsFromHitKnown = Number.isFinite(pendingWounds);
  const woundsRemaining = woundsFromHitKnown ? Math.max(pendingWounds - soaked, 0) : null;

  // Try to update actor wounds.
  // If the hit has NOT been applied yet, add woundsRemaining.
  // If the hit IS already applied, subtract soaked (capped by pending).
  let actorWoundsBefore = getActorWounds(actor);
  let actorWoundsAfter = actorWoundsBefore;

  if (woundsFromHitKnown) {
    if (actorWoundsBefore >= pendingWounds) {
      // likely already applied -> reduce
      actorWoundsAfter = Math.max(actorWoundsBefore - Math.min(soaked, pendingWounds), 0);
    } else {
      // likely not applied -> apply remaining
      actorWoundsAfter = Math.max(actorWoundsBefore + woundsRemaining, 0);
    }
    await setActorWounds(actor, actorWoundsAfter);
  } else {
    console.warn(`[${MODULE_ID}] Could not read wounds-from-hit from chat card; not changing actor wounds automatically.`);
  }

  await ChatMessage.create({
    user: game.user.id,
    speaker: ChatMessage.getSpea
