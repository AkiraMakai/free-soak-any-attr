/**
 * Free Soak Any Attribute (SWADE House Rule)
 * Foundry VTT v12 + SWADE 4.4.4 + Better Rolls 2 friendly
 *
 * What it does:
 * - Intercepts the "Soak" button on damage cards (including Better Rolls 2 cards like "Soak (Vigor) roll")
 * - Prompts the user to choose ANY Attribute
 * - Rolls that Attribute (trait + wild die fallback)
 * - Reduces CURRENT wounds accordingly (assumes damage already applied)
 * - Spends 0 Bennies
 *
 * Escape hatch:
 * - Shift+Click the Soak button to let the original module/system behavior run.
 */

const MODULE_ID = "free-soak-any-attr";

Hooks.once("init", () => {
  console.log(`[${MODULE_ID}] Init (FVTT v12 / SWADE 4.4.4 / Better Rolls 2 compatible)`);
});

Hooks.on("renderChatMessage", (message, html) => {
  if (game.system?.id !== "swade") return;

  // Better Rolls 2 sometimes uses <a> elements styled as buttons
  const clickable = html.find("button, a");

  for (const el of clickable) {
    const node = el instanceof HTMLElement ? el : el?.[0];
    if (!node) continue;

    const label = (node.textContent || "").trim().toLowerCase();
    const ds = node.dataset ?? {};
    const action = String(ds.action || ds.operation || ds.cardAction || ds.brAction || "").toLowerCase();

    // Detect "Soak" including Better Rolls 2 string: "Soak (Vigor) roll"
    const looksLikeSoak =
      action.includes("soak") ||
      label === "soak" ||
      label.includes("soak") ||
      label.includes("soak (");

    if (!looksLikeSoak) continue;

    // Prevent double-binding when chat re-renders
    if (ds.freeSoakBound === "1") continue;
    ds.freeSoakBound = "1";

    node.addEventListener(
      "click",
      async (ev) => {
        // Escape hatch: Shift+Click uses original behavior (Better Rolls / SWADE)
        if (ev.shiftKey) return;

        // Critical for Better Rolls 2: stop its handler from firing
        ev.preventDefault();
        ev.stopPropagation();
        ev.stopImmediatePropagation();

        try {
          await handleFreeSoak({ message, button: node });
        } catch (err) {
          console.error(`[${MODULE_ID}] Soak failed:`, err);
          ui.notifications?.error("Free Soak Any Attribute: failed. Check console (F12).");
        }
      },
      true // capture phase: ensures we intercept before Better Rolls handlers
    );
  }
});

async function handleFreeSoak({ message, button }) {
  const actor = await resolveActorFromContext({ message, button });
  if (!actor) {
    ui.notifications?.warn("Free Soak: Could not find the damaged actor for this Soak.");
    console.warn(`[${MODULE_ID}] Could not resolve actor`, { message, dataset: button?.dataset });
    return;
  }

  const pendingWounds = resolvePendingWounds({ message, button });

  const chosenAttr = await promptForAttribute(actor);
  if (!chosenAttr) return;

  const roll = await rollAttribute(actor, chosenAttr);
  const total = Number(roll?.total ?? roll?.result ?? NaN);
  const soaked = computeSoakFromTotal(total);

  // Damage already applied: reduce CURRENT wounds
  const currentWounds = Number(
    getProp(actor, "system.wounds.value") ??
      getProp(actor, "data.data.wounds.value") ??
      0
  );

  // If we can infer how many wounds this hit inflicted, cap by it; else cap by soaked
  const cap = Number.isFinite(pendingWounds) ? pendingWounds : soaked;
  const reduceBy = Math.min(soaked, Math.max(cap, 0), currentWounds);
  const newWounds = Math.max(currentWounds - reduceBy, 0);

  // Update actor wounds (system path first, legacy fallback)
  try {
    await actor.update({ "system.wounds.value": newWounds });
  } catch (e) {
    await actor.update({ "data.wounds.value": newWounds });
  }

  const attrLabel = attributeLabel(chosenAttr);
  const pendingText = Number.isFinite(pendingWounds) ? ` (pending: ${pendingWounds})` : "";

  await ChatMessage.create({
    user: game.user.id,
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `
      <div class="swade">
        <h3>Soak (House Rule)</h3>
        <p><b>${escapeHtml(actor.name)}</b> rolls <b>${escapeHtml(attrLabel)}</b>${pendingText}: <b>${
          Number.isFinite(total) ? total : "?"
        }</b></p>
        <p>Soaked: <b>${soaked}</b> | Wounds reduced: <b>${reduceBy}</b> | New wounds: <b>${newWounds}</b></p>
        <p style="opacity:0.8">Bennies spent: <b>0</b></p>
      </div>
    `
  });
}

async function resolveActorFromContext({ message, button }) {
  // 1) Speaker actor
  const speakerActorId = message?.speaker?.actor;
  if (speakerActorId) {
    const a = game.actors?.get(speakerActorId);
    if (a) return a;
  }

  const ds = button?.dataset ?? {};

  // 2) Dataset UUID / actor id (varies by card implementation)
  const uuid = ds.actorUuid || ds.uuid || ds.documentUuid;
  if (uuid) {
    const doc = await fromUuid(uuid);
    if (doc?.documentName === "Actor") return doc;
    if (doc?.actor) return doc.actor;
  }

  const actorId = ds.actorId || ds.actor;
  if (actorId) {
    const a = game.actors?.get(actorId);
    if (a) return a;
  }

  // 3) Better Rolls 2 flags (common)
  const brActorUuid =
    getProp(message, "flags.betterRolls.actorUuid") ||
    getProp(message, "flags.betterRolls.tokenUuid") ||
    getProp(message, "flags.betterrolls.actorUuid") || // just in case of casing differences
    getProp(message, "flags.betterrolls.tokenUuid");

  if (brActorUuid) {
    const doc = await fromUuid(brActorUuid);
    if (doc?.actor) return doc.actor;
    if (doc?.documentName === "Actor") return doc;
  }

  // 4) SWADE flags (different versions store different keys)
  const swadeFlagUuid =
    getProp(message, "flags.swade.actorUuid") ||
    getProp(message, "flags.swade.actor") ||
    getProp(message, "flags.swade.data.actorUuid") ||
    getProp(message, "flags.swade.damage.actorUuid");

  if (swadeFlagUuid) {
    const doc = await fromUuid(swadeFlagUuid);
    if (doc?.documentName === "Actor") return doc;
    if (doc?.actor) return doc.actor;
  }

  // 5) Token fallback (dataset references token)
  const tokenUuid = ds.tokenUuid || ds.token;
  if (tokenUuid) {
    const tdoc = await fromUuid(tokenUuid);
    if (tdoc?.actor) return tdoc.actor;
  }

  return null;
}

function resolvePendingWounds({ message, button }) {
  // Best-effort: depends on which damage automation produced the chat card.
  const ds = button?.dataset ?? {};
  const direct =
    ds.wounds ??
    ds.pendingWounds ??
    ds.appliedWounds ??
    ds.wound ??
    ds.w;

  const fromDataset = toNumberOrNaN(direct);
  if (Number.isFinite(fromDataset)) return fromDataset;

  // Try SWADE-ish flag locations
  const fromFlags =
    toNumberOrNaN(getProp(message, "flags.swade.damage.wounds")) ||
    toNumberOrNaN(getProp(message, "flags.swade.damageData.wounds")) ||
    toNumberOrNaN(getProp(message, "flags.swade.wounds")) ||
    toNumberOrNaN(getProp(message, "flags.swade.damageContext.wounds")) ||
    NaN;

  if (Number.isFinite(fromFlags)) return fromFlags;

  // Parse from tooltip if present (rare but sometimes)
  const title = (button?.title || "").toLowerCase();
  const m = title.match(/(\d+)\s*wound/);
  if (m) return Number(m[1]);

  // Better Rolls sometimes bakes info into message content; we won't parse HTML aggressively here.
  return NaN;
}

async function promptForAttribute(actor) {
  const attrs = ["agility", "smarts", "spirit", "strength", "vigor"];
  const options = attrs
    .map((a) => `<option value="${a}">${escapeHtml(attributeLabel(a))}</option>`)
    .join("");

  const content = `
    <form>
      <div class="form-group">
        <label>Choose Attribute for Soak</label>
        <select name="attr">${options}</select>
        <p class="notes">House rule: Soak costs 0 Bennies and may use any Attribute.</p>
      </div>
    </form>
  `;

  return await new Promise((resolve) => {
    new Dialog({
      title: `Soak (House Rule): ${actor.name}`,
      content,
      buttons: {
        ok: {
          label: "Roll Soak",
          callback: (html) => resolve(String(html.find("select[name='attr']").val()))
        },
        cancel: {
          label: "Cancel",
          callback: () => resolve(null)
        }
      },
      default: "ok"
    }).render(true);
  });
}

function attributeLabel(key) {
  return (
    {
      agility: "Agility",
      smarts: "Smarts",
      spirit: "Spirit",
      strength: "Strength",
      vigor: "Vigor"
    }[key] ?? key
  );
}

async function rollAttribute(actor, attrKey) {
  // Try SWADE methods (vary by version)
  if (typeof actor.rollAttribute === "function") {
    return await actor.rollAttribute(attrKey);
  }

  // Some versions expose rollTrait (may expect a data path or a simple key)
  if (typeof actor.rollTrait === "function") {
    try {
      return await actor.rollTrait(`system.attributes.${attrKey}`);
    } catch (e) {
      try {
        return await actor.rollTrait(attrKey);
      } catch (e2) {
        // fall through to manual roll
      }
    }
  }

  // Fallback: SWADE trait die + wild die, ace, take highest
  const traitSides =
    getProp(actor, `system.attributes.${attrKey}.die.sides`) ??
    getProp(actor, `data.data.attributes.${attrKey}.die.sides`);

  const wildSides =
    getProp(actor, `system.wildDie.sides`) ??
    getProp(actor, `data.data.wildDie.sides`) ??
    6;

  if (!traitSides) throw new Error(`Missing attribute die data for: ${attrKey}`);

  const traitRoll = await new Roll(`1d${traitSides}x`).evaluate({ async: true });
  const wildRoll = await new Roll(`1d${wildSides}x`).evaluate({ async: true });

  // Show both rolls to chat for transparency
  await traitRoll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `Soak (House Rule) - ${attributeLabel(attrKey)} (Trait Die)`
  });

  await wildRoll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `Soak (House Rule) - Wild Die`
  });

  return { total: Math.max(traitRoll.total, wildRoll.total) };
}

function computeSoakFromTotal(total) {
  // Standard SWADE Soak: success (4) soaks 1 wound, each raise adds +1
  if (!Number.isFinite(total) || total < 4) return 0;
  const raises = Math.floor((total - 4) / 4);
  return 1 + raises;
}

function toNumberOrNaN(v) {
  if (v === undefined || v === null || v === "") return NaN;
  const n = Number(v);
  return Number.isFinite(n) ? n : NaN;
}

function getProp(obj, path) {
  try {
    if (foundry?.utils?.getProperty) return foundry.utils.getProperty(obj, path);
    return path.split(".").reduce((o, k) => o?.[k], obj);
  } catch {
    return undefined;
  }
}

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
